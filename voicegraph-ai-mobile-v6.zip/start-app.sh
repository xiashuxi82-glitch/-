#!/bin/bash
cd "$(dirname "$0")"
echo "VoiceGraph AI を起動しています (http://localhost:8765) ..."
(sleep 1 && (open "http://localhost:8765" 2>/dev/null || xdg-open "http://localhost:8765" 2>/dev/null)) &
python3 -m http.server 8765
