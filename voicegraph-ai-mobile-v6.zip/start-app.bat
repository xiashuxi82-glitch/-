@echo off
cd /d "%~dp0"
chcp 65001 >nul
echo VoiceGraph AI を起動しています...

py -3 --version >nul 2>nul
if %errorlevel%==0 (
  start "" cmd /c "timeout /t 1 /nobreak >nul && start http://localhost:8765"
  py -3 -m http.server 8765
  goto :end
)

python --version >nul 2>nul
if %errorlevel%==0 (
  start "" cmd /c "timeout /t 1 /nobreak >nul && start http://localhost:8765"
  python -m http.server 8765
  goto :end
)

echo Windows標準機能(PowerShell)でローカルサーバーを起動します...
start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:8765"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$l=New-Object System.Net.HttpListener; $l.Prefixes.Add('http://localhost:8765/'); $l.Start(); Write-Host 'http://localhost:8765 で起動中 (終了するにはこの画面を閉じてください)'; while($l.IsListening){ $c=$l.GetContext(); $p=$c.Request.Url.LocalPath.TrimStart('/'); if(!$p){$p='index.html'}; $f=Join-Path (Get-Location) $p; if(Test-Path $f -PathType Leaf){ $b=[IO.File]::ReadAllBytes($f); $c.Response.ContentType=if($p -like '*.html'){'text/html; charset=utf-8'}elseif($p -like '*.json'){'application/json; charset=utf-8'}else{'application/octet-stream'}; $c.Response.OutputStream.Write($b,0,$b.Length) } else { $c.Response.StatusCode=404 }; $c.Response.Close() }"

:end
pause
